fx_version 'cerulean'
games       { 'gta5' }
author      'KaKa （2226124155）'
url		    '   https://afdian.com/a/KaKa946   '

this_is_a_map 'yes'
client_script 'client.lua'
data_file 'DLC_ITYP_REQUEST' 'apa_ch2_03.ytyp'
data_file 'DLC_ITYP_REQUEST' 'apa_ch2_03_long_5.ytyp'
data_file 'DLC_ITYP_REQUEST' 'apa_ch2_03_long_6.ytyp'
data_file 'DLC_ITYP_REQUEST' 'apa_ch2_03_strm_0.ytyp'
data_file 'DLC_ITYP_REQUEST' 'apa_ch2_03_strm_1.ytyp'
data_file 'DLC_ITYP_REQUEST' 'apa_distlodlights_medium023.ytyp'
data_file 'DLC_ITYP_REQUEST' 'ch2_03.ytyp'
data_file 'DLC_ITYP_REQUEST' 'ka_logo.ytyp'








